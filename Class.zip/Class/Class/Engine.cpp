#include <iostream>
#include "vehicle.h"
#include <string>
#include "Engine.h"

using namespace std;

Engine::Engine()
{
	
}
string Engine::getEngineSize()
{
	return engSize;
}
void Engine::setEngineSize(string size)
{
	engSize = size;
}