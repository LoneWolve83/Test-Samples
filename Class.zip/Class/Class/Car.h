#ifndef Car_h
#define Car_h

#include "vehicle.h"
#include "Engine.h"
#include <string>

using namespace std;

class Car : public vehicle
{
private:
	int numTires;
	string tireType;
	string engine;
public:
	int getNumTires(); // accessor
	void setNumTires(int nmTires); // mutator
	string getEngine();
	void setEngine(string eng);
	Car(); // constructor
	string getTireType();
	void setTireType(string trType);
	
};
#endif