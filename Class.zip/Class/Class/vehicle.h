#ifndef vehicle_H
#define vehicle_H

#include <string>

using namespace std;

class vehicle

    {
        private:
            string name;
            int year;
			int myYear; 
        public:
            string getName(); // accessor
            void setName(string nm); // mutator
            vehicle(); // default constructor
            
            int getYear(); // accessor
            void setYear(int year); //mutator 
    };

    #endif