#ifndef Truck_h
#define Truck_h

#include "vehicle.h"
#include "Engine.h"
#include <string>

using namespace std;

class Truck : public vehicle
{
private:
	int numTires;
	string tireType;
	string engine;
public:
	int getNumTires(); // accessor
	void setNumTires(int nmTires); // mutator
	string getEngine();
	void setEngine(string eng);
	Truck(); // constructor
	string getTireType();
	void setTireType(string trType);
	
};
#endif