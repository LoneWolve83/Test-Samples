#include <iostream>
#include "vehicle.h"
#include <string>

using namespace std;

string vehicle;

   vehicle::vehicle()
    {
        }
    string vehicle::getName()
    {
        return name;
        }
    void vehicle::setName(std::string nm) /// here?

    {
        name = nm;
        }
        
     void vehicle::setYear(int year)
        {
			myYear = year;
        }
        int vehicle::getYear()
        {
            return myYear;
        }