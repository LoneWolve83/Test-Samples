#include <iostream>
#include "vehicle.h"
#include <string>
#include "Truck.h"

using namespace std;


Truck::Truck()
{
}
int Truck::getNumTires()
{
        return numTires;
}
void Truck::setNumTires(int nmTires)
{
        numTires = nmTires;
}

string Truck::getTireType()
{
        return tireType;
}
void Truck::setTireType(string trType)
{
        tireType = trType;
}
string Truck::getEngine()
{
	return engine;
}
void Truck::setEngine(string eng)
{
	engine = eng;
}