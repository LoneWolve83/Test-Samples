#ifndef Engine_h
#define Engine_h

#include "vehicle.h"
#include <string>

using namespace std;

class Engine : public vehicle
{
private:
	int size;
	string engSize;
public:
	Engine();
	Engine(int size);
	string getEngineSize();
	void setEngineSize(string size);
};

#endif