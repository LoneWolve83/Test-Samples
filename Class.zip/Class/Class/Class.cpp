#include <iostream>
#include <fstream>
#include <string> // include the string
#include "vehicle.h" // including the header file "vehicle"
#include "Car.h" // include the header file "car"
#include "Engine.h" // include the header file "engine"
#include "Truck.h" // include the header file "truck"

using namespace std; // uses the std

// declarations
int name;
int setName;
int setYear;

int main()
{
string readAlong; //string variable for getline operation
string greetBack = "Hello Back.";
ifstream inputFileNAME;
ofstream outputFileNAME;

inputFileNAME.open("greeting.txt"); //Opens the file to be read from
outputFileNAME.open("NewFileNAME.txt"); //Tells Visual Studio to create the output text file

if (inputFileNAME.is_open()) // IF statement that determines whether the file has been opened yet or not
{
     while (inputFileNAME.good()) //While loop to read from the file if it is 'found' or if it is does in fact exist
     {
            getline (inputFileNAME, readAlong); /*getline is like an automated cout from the IDE that continues to read   with a string variable
*/

            cout << readAlong << endl;

      } //end while
     inputFileNAME.close();
}//end IF
outputFileNAME << greetBack;
outputFileNAME.close();

    {
        vehicle boat; // create instance of vehicle
        boat.setName("Titanic"); // name the vehicle
        boat.setYear(1912); // state the year of its demise
        Car car; //create instance of car
		Truck truck; // create instance of truck
		car.setName("Ford Mustang"); // name of the car /// i set name of car here with no issues......because you have a function 
		truck.setName("Dodge Ram"); // danme of the truck where is your func
		car.setNumTires(4); // state the number of tires
		truck.setNumTires(4); // state the number of tires
		car.setTireType("Goodyear"); // state the brand of tire
		truck.setTireType("BF Goodwrench");// state the brand of tire
		Engine engine;
		engine.setEngineSize("5.0");
		car.setEngine("Turbo-Charged");
		truck.setEngine("Hemi 5.7");
		
		{
        cout << "The name of the boat is " << boat.getName() << endl; // output vehicle name
        cout << "The year it sank is " << boat.getYear() << endl; // output year

		cout << "The number of tires on the car is " << car.getNumTires() << endl; // output number of tires
		cout << "And the name of the car is the " << car.getName() << endl; // output name of car
		cout << "The brand of tire on the " << car.getName() << " is " << car.getTireType() << endl; // output brand of tire
		cout << "The size of the engine in a " << car.getName() << " is a " << car.getEngine() << " " << engine.getEngineSize() << endl;
		cout << "The number of tires on the Truck is " << truck.getNumTires() << endl;
		cout << "The name of the truck is " << truck.getName()  << endl;
		cout << "The brand of tire on the " << truck.getName() << " is " << truck.getTireType() << endl;
		cout << "The engine in the " << truck.getName() << " is a " << truck.getEngine() << endl;

		//Engine tempEng = car.getEngine(); // another way to have done the previous line with a following cout 
		}

		cin.get();// user hits enter to close
		cin.get();//

        return 0;
    }

}