#include <iostream>
#include "vehicle.h"
#include <string>
#include "Car.h"

using namespace std;


Car::Car()
{

}
int Car::getNumTires()
{
        return numTires;
}
void Car::setNumTires(int nmTires)
{
        numTires = nmTires;
}

string Car::getTireType()
{
        return tireType;
}
void Car::setTireType(string trType)
{
        tireType = trType;
}
string Car::getEngine()
{
	return engine;
}
void Car::setEngine(string eng)
{
	engine = eng;
}